// viperx_controller.cpp

#include "viperx_controller.hpp"

ViperXController::ViperXController() : node_(rclcpp::Node::make_shared("viperx_controller")), move_group_("arm")
{
    move_group_.setPlanningTime(10);
}

void ViperXController::getPose(const Eigen::Vector3d& position)
{
    geometry_msgs::msg::PoseStamped target_pose;
    target_pose.pose.position.x = position.x();
    target_pose.pose.position.y = position.y();
    target_pose.pose.position.z = position.z();
    target_pose.pose.orientation.w = 1.0;

    move_group_.setPoseTarget(target_pose);
    moveit::planning_interface::MoveGroupInterface::Plan my_plan;
    bool success = (move_group_.plan(my_plan) == moveit::planning_interface::MoveItErrorCode::SUCCESS);
    if (success)
    {
        move_group_.move();
        RCLCPP_INFO(node_->get_logger(), "Movement to position (%f, %f, %f) successful", position.x(), position.y(), position.z());
    }
    else
    {
        RCLCPP_ERROR(node_->get_logger(), "Failed to move to position (%f, %f, %f)", position.x(), position.y(), position.z());
    }
}