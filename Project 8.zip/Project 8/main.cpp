// main.cpp

#include "viperx_controller.hpp"

int main(int argc, char** argv)
{
    rclcpp::init(argc, argv);
    auto controller = std::make_shared<ViperXController>();

    // Example usage:
    Eigen::Vector3d target_position(0.1, 0.2, 0.3);
    controller->getPose(target_position);

    rclcpp::shutdown();
    return 0;
}